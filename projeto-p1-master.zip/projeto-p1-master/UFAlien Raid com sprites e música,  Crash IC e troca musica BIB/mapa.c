#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

const int TILESIZE = 50;

enum
{
    GRAMA = 1,
    BLOCO = 2,
    NBLOCO = 3,//SUBSTITUIR OS TILES POR IMAGENS
    CHAO = 4,
    PISO = 5,
    ESTANTE_H = 6,
    ESTANTE_VD = 7,
    ESTANTE_VE = 8,
    RUA_V = 9,
    RUA_H = 10,
    CURVA_EC = 11,
    CURVA_EB = 12,
    CURVA_DC = 13,
    CURVA_DB = 14,
    AVENIDA = 15,
    CRUZAMENTO_T = 16,
    CRUZAMENTO_X = 17,
    ARVORE = 18,
    IC = 19,
    BIBLIOTECA = 20,
    PAZ = 21,
};

int** carregar_mapa(const char* arquivo, int* linhas, int* colunas)
{
    FILE* f = fopen(arquivo, "r");
    int** matriz;

    if(f != NULL)
    {
        int i, j;
        fscanf(f, "%d %d", linhas, colunas);

        matriz = (int**) malloc ( (*linhas) * sizeof(int*));
        for(i = 0; i < *linhas; i++) matriz[i] = (int*) malloc( (*colunas) * sizeof(int));

        for(i = 0; i < *linhas; i++)
        {
            for(j = 0; j < *colunas; j++)
            {
            fscanf(f, "%d", &matriz[i][j]);//queria saber o que é um fscanf
            }
        }

     fclose(f);
    }
    return matriz;
}

void desenhar_mapa(BITMAP* buffer, int** mapa, int linhas, int colunas)//esse eu uso os coiso da outra pra pintar os quadrados, quando formos incrementar o mapa é só mexer nessa aqui eu acho
{
    int i, j;
    BITMAP* chao = load_bitmap("sprites/mapas/chao.bmp", NULL);
    BITMAP* rua_v = load_bitmap("sprites/mapas/rua_v.bmp", NULL);
    BITMAP* rua_h = load_bitmap("sprites/mapas/rua_h.bmp", NULL);
    BITMAP* curva_ec = load_bitmap("sprites/mapas/curva_ec.bmp", NULL);
    BITMAP* curva_eb = load_bitmap("sprites/mapas/curva_ed.bmp", NULL);
    BITMAP* curva_dc = load_bitmap("sprites/mapas/curva_dc.bmp", NULL);
    BITMAP* curva_db = load_bitmap("sprites/mapas/curva_db.bmp", NULL);
    BITMAP* avenida = load_bitmap("sprites/mapas/avenida.bmp", NULL);
    BITMAP* cruzamento_t = load_bitmap("sprites/mapas/cruzamento_t.bmp", NULL);
    BITMAP* cruzamento_x = load_bitmap("sprites/mapas/cruzamento_x.bmp", NULL);
    BITMAP* gramado = load_bitmap("sprites/mapas/grama.bmp", NULL);
    BITMAP* arvore = load_bitmap("sprites/mapas/arvore.bmp", NULL);
    BITMAP* piso_ic = load_bitmap("sprites/mapas/piso.bmp", NULL);
    BITMAP* estante_h = load_bitmap("sprites/objetos/estante_h.bmp", NULL);
    BITMAP* estante_ve = load_bitmap("sprites/objetos/estante_ve.bmp", NULL);
    BITMAP* estante_vd = load_bitmap("sprites/objetos/estante_vd.bmp", NULL);



    for(i = 0; i < linhas; i++)
     {
        for(j = 0; j < colunas; j++)
        {
           if(mapa[i][j] == GRAMA) draw_sprite(buffer, gramado, j * TILESIZE, i * TILESIZE);

           else if(mapa[i][j] == BLOCO) rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(70,160,255));

           else if(mapa[i][j] == NBLOCO) rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(215,0,0));

           else if(mapa[i][j] == CHAO) draw_sprite(buffer, chao, j * TILESIZE, i * TILESIZE);

           else if(mapa[i][j] == PISO) draw_sprite(buffer, piso_ic, j * TILESIZE, i * TILESIZE);

           else if(mapa[i][j] == ESTANTE_H) draw_sprite(buffer, estante_h, j * TILESIZE, i * TILESIZE);
           else if(mapa[i][j] == ESTANTE_VE) draw_sprite(buffer, estante_ve, j * TILESIZE, i * TILESIZE);
           else if(mapa[i][j] == ESTANTE_VD) draw_sprite(buffer, estante_vd, j * TILESIZE, i * TILESIZE);

             else if(mapa[i][j] == RUA_V) draw_sprite(buffer, rua_v, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == RUA_H) draw_sprite(buffer, rua_h, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CURVA_EC) draw_sprite(buffer, curva_ec, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CURVA_EB) draw_sprite(buffer, curva_eb, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CURVA_DC) draw_sprite(buffer, curva_dc, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CURVA_DB) draw_sprite(buffer, curva_db, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == AVENIDA) draw_sprite(buffer, avenida, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CRUZAMENTO_T) draw_sprite(buffer, cruzamento_t, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == CRUZAMENTO_X) draw_sprite(buffer, cruzamento_x, j * TILESIZE, i * TILESIZE);
             else if(mapa[i][j] == ARVORE) draw_sprite(buffer, arvore, j * TILESIZE, i * TILESIZE);
        }
     }
     destroy_bitmap(piso_ic);
     destroy_bitmap(estante_h);
     destroy_bitmap(estante_vd);
     destroy_bitmap(estante_ve);
     destroy_bitmap(rua_v);
     destroy_bitmap(rua_h);
     destroy_bitmap(curva_ec);
     destroy_bitmap(curva_eb);
     destroy_bitmap(curva_dc);
     destroy_bitmap(curva_db);
     destroy_bitmap(gramado);
     destroy_bitmap(avenida);
     destroy_bitmap(arvore);
}

void libera_mapa(int** mapa, int linhas)
{
   int i;
   for(i = 0; i < linhas; i++) free(mapa[i]);

  	free(mapa);
}
