#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"

volatile int sair;

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

int main()
{
    init();
    //historia(ticks, 1);

    while(!sair)
    {
      if(estado_tela == MAINMENU) menu();
      else if(estado_tela == GAMESCREEN) game();
    }

  return 0;
}
END_OF_MAIN()
