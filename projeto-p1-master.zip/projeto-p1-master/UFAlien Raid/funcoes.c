#include <stdio.h>
#include <allegro.h>

volatile int sair;
void fecha_programa() { sair = TRUE; }
END_OF_FUNCTION(fecha_programa);

volatile int ticks;
void conta_ticks(){ ticks++; }
END_OF_FUNCTION(conta_ticks);

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void init()
{
   allegro_init();
   install_timer();
   install_mouse();
   install_keyboard();
   set_color_depth(32);
   set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 1280, 720, 0, 0);
   set_window_title("UFALien Raid");

   sair = FALSE;
   LOCK_FUNCTION(fecha_programa);
   LOCK_VARIABLE(sair);
   set_close_button_callback(fecha_programa);

   ticks = 0;
   LOCK_FUNCTION(conta_ticks);
   LOCK_VARIABLE(ticks);
   install_int_ex(conta_ticks, BPS_TO_TIMER(60));

   estado_tela = MAINMENU;
}
END_OF_FUNCTION(init);

void historia(int nticks, int img)
{
    int t = 0;
    int sec = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    while(t < 1820)
    {
        LOCK_VARIABLE(nticks);
        t = ticks - nticks;
        if((t % 60) == 0) sec = t/60;
        textprintf_centre_ex(buffer, font, SCREEN_W/2 + 100, SCREEN_H/2, makecol(255,255,255), -1, "%ds", sec);
        textout_centre_ex(buffer, font, "DESCRICAO AQUI", SCREEN_W/2, SCREEN_H/2, makecol(255,255,255), -1);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
    }
    destroy_bitmap(buffer);
}
END_OF_FUNCTION(historia);

void game()
{
  int sair_da_tela = FALSE;

  //BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* boneco = load_bitmap("sprites/boneco.bmp", NULL);
  BITMAP* sky = load_bitmap("sprites/sky.bmp", NULL);
  BITMAP* montanha = load_bitmap("sprites/montanha.bmp", NULL);

  ///GAME LOOP
  while(!sair && !sair_da_tela)
  {
    while(ticks > 0 && !sair && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ENTER])
      {
        sair_da_tela = TRUE;
        estado_tela = MAINMENU;
      }

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, sky, 0, 0);
      draw_sprite(buffer, montanha, 0, 0);
      draw_sprite(buffer, boneco, 150, 430);
      draw_sprite(screen, buffer, 0, 0);
      clear(buffer);
    }
  }
  destroy_bitmap(buffer);
  destroy_bitmap(boneco);
  destroy_bitmap(sky);
  destroy_bitmap(montanha);
}
END_OF_FUNCTION(game);

void menu()
{
  int sair_da_tela = FALSE;
  int pos_botao_hor1 = 590;
  int pos_botao_hor2 = 683;
  int pos_botao_ver1 = 200;
  int pos_botao_ver2 = 236;


  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
  BITMAP* highlight = load_bitmap("sprites/highlight.bmp", NULL);
  BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);


  while(!sair && !sair_da_tela)///GAME LOOP
  {
    while(ticks > 0 && !sair && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ESC]) fecha_programa();

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 100);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 200);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 300);

      if(mouse_x >= pos_botao_hor1  && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 &&  mouse_y <= pos_botao_ver2)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1);
          if(mouse_b == 1)
            {
              textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              historia(ticks, 1);
              estado_tela = GAMESCREEN;
              game();
            }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 100 &&  mouse_y <= pos_botao_ver2 + 100)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 100);
          if(mouse_b == 1) textout_ex(buffer, font, "CARREGAR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 200 &&  mouse_y <= pos_botao_ver2 + 200)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 200);
          if(mouse_b == 1) textout_ex(buffer, font, "CREDITOS PRESSIONADO", 590, 100, makecol(0,0,0), -1);
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 &&  mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 300 &&  mouse_y <= pos_botao_ver2 + 300)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 300);
          if(mouse_b == 1) textout_ex(buffer, font, "SAIR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
          //mouse_b = 0;
      }

      draw_sprite(buffer, cursor, mouse_x-8, mouse_y);
      draw_sprite(screen, buffer, 0, 0);
      clear_to_color(buffer, makecol(255, 255, 255));

      ///ATUALIZAR TICKS
      ticks--;
    }
  }
  /// DESTRUIR BITMAPS
  destroy_bitmap(buffer);
  destroy_bitmap(button);
  destroy_bitmap(highlight);
  destroy_bitmap(cursor);
}
END_OF_FUNCTION(menu);
