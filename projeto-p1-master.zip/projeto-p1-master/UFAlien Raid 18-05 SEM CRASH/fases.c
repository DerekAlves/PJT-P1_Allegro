#include <allegro.h>
#include <stdio.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "fases.h"
#include "personagem.h"

BITMAP* link[4][7];
int ticks;

void icomp(float pos[2])
{
	int score = 1000;
	int linhas, colunas;
	BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	BITMAP* mesa_prof = load_bitmap("sprites/objetos/professor.bmp", NULL);
  	BITMAP* cadeira = load_bitmap("sprites/objetos/cadeira.bmp", NULL);
  	SAMPLE* takeonme = load_sample("musicas/takeonme.wav");

  	int** ic = carregar_mapa("mapas/ic.txt", &linhas, &colunas);
  	play_sample(takeonme, 255, 128, 1000, TRUE);

  	while(score > 0 && !key[KEY_BACKSPACE])
	{
		desenhar_mapa(buffer, ic, linhas, colunas);
		personagem(buffer, link, pos);

		draw_sprite(screen, buffer, 0, 0);
		clear(buffer);

	}
	libera_mapa(ic, linhas);
	stop_sample(takeonme);
	destroy_sample(takeonme);
	destroy_bitmap(buffer);
	destroy_bitmap(mesa_prof);
	destroy_bitmap(cadeira);
}
END_OF_FUNCTION(icomp);

void bibli(float pos[2])
{
	int score = 1000;
	int linhas, colunas;
	BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	int** biblioteca = carregar_mapa("mapas/bib.txt", &linhas, &colunas);
	SAMPLE* another = load_sample("musicas/another.wav");

	play_sample(another, 255, 128, 1000, TRUE);

	while(score > 0 && !key[KEY_BACKSPACE])
	{
		desenhar_mapa(buffer, biblioteca, linhas, colunas);
		personagem(buffer, link, pos);
		draw_sprite(screen, buffer, 0, 0);
		clear(buffer);
    }
	libera_mapa(biblioteca, linhas);
	destroy_bitmap(buffer);
	stop_sample(another);
	destroy_sample(another);
}
END_OF_FUNCTION(bibli);

void ufal(float pos[2])
{
    int estmus = 0;
	int linhas, colunas;
	BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	int** mapa = carregar_mapa("mapas/mapa.txt", &linhas, &colunas);
	SAMPLE* paint = load_sample("musicas/paint.wav");
	load(link);

	///VARIAVEIS POSICAO BIB E IC PARA COLISAO
    int pos_xi_ic = 250;
    int pos_xf_ic = 300;
    int pos_yi_ic = 350;
    int pos_yf_ic = 450;
    /// ///////////////// FIM IC /// INICIO BIB
    int pos_xi_bi = 806;
    int pos_xf_bi = 845;
    int pos_yi_bi = 404;
    int pos_yf_bi = 494;

    play_sample(paint, 255, 128, 1000, TRUE);

	while(!key[KEY_HOME])
	{
		if(pos[0] > pos_xi_ic && pos[0] < pos_xf_ic && pos[1] > pos_yi_ic && pos[1] < pos_yf_ic)
		{
			textout_ex(buffer, font, "ENTROU NO IC", 250, 450, makecol(0,0,0), -1);
            if(key[KEY_ENTER])
            {
                estmus = 1;
            	stop_sample(paint);
            	icomp(pos);
            	play_sample(paint, 255, 128, 1000, TRUE);
            }

		}
		else if (pos[0] > pos_xi_bi && pos[0] < pos_xf_bi && pos[1] > pos_yi_bi && pos[1] < pos_yf_bi)
        {
            textout_ex(buffer, font, "ENTROU NA BIBLIOTECA", 806, 494, makecol(0,0,0), -1);
            if(key[KEY_ENTER])
            {
                estmus = 1;
                stop_sample(paint);
            	bibli(pos);
            	play_sample(paint, 255, 128, 1000, TRUE);
            }
        }
        //if(estmus == 1) play_sample(paint, 255, 128, 1000, TRUE);

        desenhar_mapa(buffer, mapa, linhas, colunas);
        personagem(buffer, link, pos);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
        ticks--;
	}
	libera_mapa(mapa, linhas);
	stop_sample(paint);
	destroy_sample(paint);
	destroy_bitmap(buffer);
	destroy(link);
}
END_OF_FUNCTION(ufal);
