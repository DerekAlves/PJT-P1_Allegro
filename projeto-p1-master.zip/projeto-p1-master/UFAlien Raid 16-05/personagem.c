#include <allegro.h>
#include <stdio.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void personagem(BITMAP* buffer, BITMAP* link[][7], float pos[2])
{
	int num_frames = 6;
  	int frame_atual = 0; // animação de cada estado (andar)
  	int frame_vatual = 0; // é o estado de animação para esquerda, direita, cima ou baixo. 0 -> direita, 1-> cima, 2-> baixo, 3-> esquerda
  	int tempo_troca = 150;
  	float speed = 1.5;
  	load(link);

  	if (key[KEY_RIGHT])
    {
    //atualizamos o frame apenas em cada comando
    	frame_vatual = 0;
    	pos[0] = pos[0] + speed;
    	frame_atual = (milisegundos/tempo_troca) % num_frames; //então cada frame terá 1 ms
	}
    else if (key[KEY_DOWN])
    {
      	frame_vatual = 2;
      	pos[1] = pos[1] + speed;
       	frame_atual = (milisegundos/tempo_troca) % num_frames; //então cada frame terá 1 ms
  	}
  	else if (key[KEY_UP])
  	{
      	frame_vatual = 1;
      	pos[1] = pos[1] - speed;;
      	frame_atual = (milisegundos/tempo_troca) % num_frames;
  	}
  	else if (key[KEY_LEFT])
  	{
      	frame_vatual = 3;
      	pos[0] = pos[0] - speed;
      	frame_atual = (milisegundos/tempo_troca) % num_frames;
  	}

  	///ANIMACAO

  	if (frame_vatual == 0 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
	{
        frame_atual = 0;
      	frame_vatual = 0;
    }
    if (frame_vatual == 1 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
    {

   		frame_atual = 0;
        frame_vatual = 1;
    }
  	if (frame_vatual == 2 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
  	{
      	frame_atual = 0;
      	frame_vatual = 2;
  	}
  	if (frame_vatual == 3 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
  	{
      	frame_atual = 0;
      	frame_vatual = 3;
  	}

  	if (key[KEY_R])
    {
        pos[0] = 200;
        pos[1] = 300;
    }

    draw_sprite(buffer, link[frame_vatual][frame_atual], pos[0], pos[1]);
}
END_OF_FUNCTION(personagem);
