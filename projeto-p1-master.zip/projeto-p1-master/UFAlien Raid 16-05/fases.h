/*CABECALHO PARA CHAMAR AS FASES*/

void ufal(float pos[2]);
//CHAMA A FASE PRINCIPAL, UFAL


void icomp(float pos[2]);
//CHAMA A FASE DO IC


void bibli(float pos[2]);
//CHAMA A FASE DA BIBLIOTECA
