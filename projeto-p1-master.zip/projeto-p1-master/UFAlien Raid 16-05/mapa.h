#include <allegro.h>
/*CABECALHOS DE FUNCOES PARA O MAPA

*/

/*ATENCAO!!!!!!!!
DEVE SE ACRESCENTAR ESTAS VARIAVEIS GLOBAIS NO INICIO DO CODIGO

const int TILESIZE = 50; //TAMANHO DO TILE

E O ENUM A SEGUIR

enum
{
    GRAMA = 1,
    BLOCO = 2,
    NBLOCO = 3,//SUBSTITUIR OS TILES POR IMAGENS
    CHAO = 4
};

*/

int** carregar_mapa(const char* arquivo, int* linhas, int* colunas);
/* PARAMETROS PONTEIRO PARA ARQUIVO TXT DE TILEMAP, LINHAS E COLUNAS DA MATRIZ
*/

void desenhar_mapa(BITMAP* buffer, int** mapa, int linhas, int colunas);
/* PARAMETROS PONTEIRO O BUFFER, PONTEIRO PARA PONTEIRO DO MAPA< LINHAS E COLUNAS DA MATRIZ
*/

void libera_mapa(int** mapa, int linhas);
/* PARAMETROS PONTEIRO PARA PONTEIRO DO MAPA< LINHAS DA MATRIZ;
*/
