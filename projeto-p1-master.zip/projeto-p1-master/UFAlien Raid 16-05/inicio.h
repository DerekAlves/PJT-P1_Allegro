/*CABECALHO FUNCOES UFALien Raid

FUNCOES IMPLEMENTADAS PARA REDUZIR O TAMANHO DOS ARQUIVOS
FUNCOES PARA INICIALIZAR E FINALIZAR O CODIGO
*/

/*ATENCAO!!!!!!!!
DEVE SE ACRESCENTAR ESTAS VARIAVEIS GLOBAIS NO INICIO DO CODIGO

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

*/

void fecha_programa();
/* FECHA O PROGRAMA*/

void tick_counter();
/*CONTA OS TICKS*/

void msec_counter();
/* CONTA MILISEGUNDOS*/

void init();
/* INICIALIZA TUDO QUE EH NECESSARIO PARA RODAR O JOGO*/
