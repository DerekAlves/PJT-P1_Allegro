#include <allegro.h>


void load(BITMAP* link[][7]);


void destroy(BITMAP* link[][7]);
