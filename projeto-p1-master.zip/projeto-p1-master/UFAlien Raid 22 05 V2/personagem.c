#include <allegro.h>
#include <stdio.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "fases.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum{ MAINMENU, GAMESCREEN };
int estado_tela;
int frame_atual = 0;
int frame_vatual = 0;

void personagem(BITMAP* buffer, BITMAP* boneco[][3], float pos[2],float speedx, float speedy)
{
    int num_frames = 3;
  	//frame_atual = 0; // animação de cada estado (andar)
  	//frame_vatual = 0; // é o estado de animação para esquerda, direita, cima ou baixo. 0 -> direita, 1-> cima, 2-> baixo, 3-> esquerda
  	int tempo_troca = 150;
  	speedx = 2;
  	speedy = 2;

    if (key[KEY_RIGHT] && pos[0]<1250)
    {
    //atualizamos o frame apenas em cada comando
    	frame_vatual = 1;
    	pos[0] = pos[0] + speedx;

    	frame_atual = (milisegundos/tempo_troca) % num_frames; //então cada frame terá 1 ms
	}
    else if (key[KEY_DOWN] && pos[1]<686)
    {
      	frame_vatual = 0;
      	pos[1] = pos[1] + speedy;

       	frame_atual = (milisegundos/tempo_troca) % num_frames; //então cada frame terá 1 ms
  	}
  	else if (key[KEY_UP] && pos[1] >0)
  	{
      	frame_vatual = 2;
      	pos[1] = pos[1] - speedy;

      	frame_atual = (milisegundos/tempo_troca) % num_frames;
  	}
  	else if (key[KEY_LEFT] && pos[0]>0)
  	{
      	frame_vatual = 3;
      	pos[0] = pos[0] - speedx;

      	frame_atual = (milisegundos/tempo_troca) % num_frames;
  	}

    ///ANIMACAO

  	if (frame_vatual == 0 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
	{
        frame_atual = 0;
      	frame_vatual = 0;
    }
    if (frame_vatual == 1 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
    {

   		frame_atual = 0;
        frame_vatual = 1;
    }
  	if (frame_vatual == 2 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
  	{
      	frame_atual = 0;
      	frame_vatual = 2;
  	}
  	if (frame_vatual == 3 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
  	{
      	frame_atual = 0;
      	frame_vatual = 3;
  	}

    draw_sprite(buffer, boneco[frame_vatual][frame_atual], pos[0], pos[1]);
}
END_OF_FUNCTION(personagem);
