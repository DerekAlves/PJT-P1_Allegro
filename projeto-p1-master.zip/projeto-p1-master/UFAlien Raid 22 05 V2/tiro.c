int flag_tiro = 1;

struct projeteis // global
{
	//int id; //??
	int x;
	int y;
	int velocidade;
	int ativo; // ativar ou desativar a municao -> 0 para desativado e 1 para desativado


}balas[num_balas];

     //VARIAVEIS GLOBAIS
    float pos_x = 300;
    float pos_y = 400;
    float speed_x = 5;
    float speed_y = 5;
    int flag_tiro;

enum
{
    ATIVO,
    NAO_ATIVO
};


 BITMAP* bullet;

void iniciar_tiros() // carregar os tiros num array
{
    int i;
    for (i=0; i<num_balas; i++)
    {
        balas[i].ativo = NAO_ATIVO;
        balas[i].velocidade = 20;
    }
     bullet = load_bitmap("bullet.bmp",NULL);
     flag_tiro = 0;

}
void show_tiros() //movimentacao dos projeteis
{

    int i;
    for (i=0; i<num_balas; i++)
    {
        if (balas[i].ativo == ATIVO)
        {
            draw_sprite(buffer, bullet, balas[i].x, balas[i].y);
            if (balas[i].x > buffer->w)
            {
                balas[i].ativo = NAO_ATIVO;
            }
            else
            {
                 balas[i].x+=balas[i].velocidade;

            }
        }
    }
}




void atirar() // acionar os tiros com uma tecla
{
    int i;
    for (i=0; i<num_balas; i++)
    {
        if (balas[i].ativo == NAO_ATIVO)
        {
            balas[i].ativo = ATIVO;
            balas[i].x = pos_x + 130;
            balas[i].y = pos_y + 48;

            break;
        }
    }
}



volatile int exit_program;
void fecha_programa() {exit_program = TRUE; }
END_OF_FUNCTION(fecha_programa)

volatile int ticks;
void tick_counter()
{
    ticks++;
}
END_OF_FUNCTION(tick_counter)


int main()
{
    allegro_init();
    install_timer();
    install_keyboard();
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800,600,0,0);
    set_close_button_callback(fecha_programa);
    set_window_title("Tirao");
    iniciar_tiros();
    ticks = 0;
    LOCK_FUNCTION(tick_counter);
    LOCK_VARIABLE(ticks);
    install_int_ex(tick_counter, BPS_TO_TIMER(60)); //30 Hz 30 atualiza��es por segundo

    //BITMAPS
    buffer = create_bitmap(SCREEN_W, SCREEN_H);
    BITMAP* nave = load_bitmap("nave.bmp",NULL);

    //SONS
    SAMPLE* sfx = load_sample("sfx.wav");
    int estado_anterior_SPACE;


    //GAME LOOP
    while (!exit_program)
    {


        while (ticks > 0) // sendo ticks come�ando com 0, quando come�ar o loop do game, ocorrer� uma atualiza��o (ticks = 1), assim entra nesse loop, atualiza o jogo e decrementa no final
        {
            //o tick � feito usando o timer para padronizar a atualiza��o do c�digo
            //INPUT
            if (key[KEY_ESC])
            {
                 fecha_programa();
            }

            if (key[KEY_R])
            {
                pos_x = 0;
                pos_y = 0;
            }
            pos_x = 0;
            estado_anterior_SPACE = key[KEY_SPACE];
            poll_keyboard();
            //UPDATE
            //pos_y = pos_y - speed_y; // lembre que o eixo y � invertido - para baixo � positivo e cima � negativo

            if (pos_y < 0)
            {
                 speed_y *= -1;
            }
            else if (pos_y>485)
            {
                speed_y *= -1;
            }
            pos_y += speed_y;

            if(flag_tiro == 1)
            {
                play_sample(sfx, 50, 128, 1000, FALSE);
                atirar();
            }
            flag_tiro++;
            if(flag_tiro == 12) flag_tiro = 1;

            draw_sprite_ex(buffer,nave, pos_x, pos_y, DRAW_SPRITE_NORMAL, DRAW_SPRITE_NO_FLIP);
            show_tiros();
            draw_sprite(screen, buffer, 0,0);
            clear_to_color(buffer,makecol(255,255,255));
            ticks--;
        }


    }
    //FIM
    destroy_sample(sfx);
    destroy_bitmap(buffer);
    destroy_bitmap(nave);
    destroy_bitmap(bullet);
    return 0;
}
END_OF_MAIN();
