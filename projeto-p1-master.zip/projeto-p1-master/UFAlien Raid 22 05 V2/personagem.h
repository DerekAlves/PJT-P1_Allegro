////CABECALHO PARA O PERSONAGEM

///CONTEM MOVIMENTO, ANIMACAO E COLISAO

void personagem(BITMAP* buffer, BITMAP* boneco[][3], float pos[2]);
//CARREGA E DESENHA ANIMACAO
//float bounding_box_collision(float posc[2], float w1, float h1, float x2, float y2, float w2, float h2);
