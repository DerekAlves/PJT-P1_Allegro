#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
   /* int frame_atual = 0;
  	int frame_vatual = 0;*/

void load(BITMAP* boneco[][3])
{



      boneco[0][0] = load_bitmap("bmp/boneco10.bmp",NULL);
      boneco[0][1] = load_bitmap("bmp/boneco11.bmp",NULL);
      boneco[0][2] = load_bitmap("bmp/boneco12.bmp",NULL);

      boneco[1][0] = load_bitmap("bmp/boneco20.bmp",NULL);
      boneco[1][1] = load_bitmap("bmp/boneco21.bmp",NULL);
      boneco[1][2] = load_bitmap("bmp/boneco22.bmp",NULL);

      boneco[2][0] = load_bitmap("bmp/boneco30.bmp",NULL);
      boneco[2][1] = load_bitmap("bmp/boneco31.bmp",NULL);
      boneco[2][2] = load_bitmap("bmp/boneco32.bmp",NULL);

      boneco[3][0] = load_bitmap("bmp/boneco40.bmp",NULL);
      boneco[3][1] = load_bitmap("bmp/boneco41.bmp",NULL);
      boneco[3][2] = load_bitmap("bmp/boneco42.bmp",NULL);
}
END_OF_FUNCTION(load);

void destroy(BITMAP* boneco[][3])
{
  destroy_bitmap(boneco[0][0]);
  destroy_bitmap(boneco[0][1]);
  destroy_bitmap(boneco[0][2]);
  destroy_bitmap(boneco[1][0]);
  destroy_bitmap(boneco[1][1]);
  destroy_bitmap(boneco[1][2]);
  destroy_bitmap(boneco[2][0]);
  destroy_bitmap(boneco[2][1]);
  destroy_bitmap(boneco[2][2]);
  destroy_bitmap(boneco[3][0]);
  destroy_bitmap(boneco[3][1]);
  destroy_bitmap(boneco[3][2]);
}
END_OF_FUNCTION(destroy);
