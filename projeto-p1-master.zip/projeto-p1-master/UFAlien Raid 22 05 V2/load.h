#include <allegro.h>


void load(BITMAP* boneco[][3]);


void destroy(BITMAP* boneco[][3]);
