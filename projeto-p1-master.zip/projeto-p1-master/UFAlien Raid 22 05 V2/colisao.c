#include <allegro.h>
#include "funcoes.h"

