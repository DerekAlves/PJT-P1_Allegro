#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "personagem.h"
#include "fases.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

float pos_x = 315;///
float pos_y = 215;///POSICAO PERSONAGEM

float pos[2];

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void historia(int nticks, int img)
{
    int t = 0;
    int sec = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    while(t < 181)//30s
    {
        if(key[KEY_ENTER]) break;
        LOCK_VARIABLE(nticks);
        t = ticks - nticks;
        if((t % 60) == 0) sec = t/60;
        textprintf_centre_ex(buffer, font, SCREEN_W/2 + 100, SCREEN_H/2, makecol(255,255,255), -1, "%ds", sec);
        textout_centre_ex(buffer, font, "GAME OVER", SCREEN_W/2, SCREEN_H/2, makecol(255, 255, 255), -1);
        pos[0] = 315;
        pos[1] = 215;
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
    }
    destroy_bitmap(buffer);
}
END_OF_FUNCTION(historia);

void game()
{
  int sair_da_tela = FALSE;
  pos[0] = pos_x;
  pos[1] = pos_y;

  ufal(pos);
}
END_OF_FUNCTION(game);

void menu()
{
  int sair_da_tela = FALSE;
  int pos_botao_hor1 = 390;
  int pos_botao_hor2 = 890;
  int pos_botao_ver1 = 300;
  int pos_botao_ver2 = 450;


  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* arte = load_bitmap("sprites/artejogo.bmp", NULL);
  BITMAP* fundo = load_bitmap("sprites/fundo.bmp", NULL);
  BITMAP* iniciar = load_bitmap("sprites/iniciar.bmp", NULL);
  BITMAP* iniciar_h = load_bitmap("sprites/iniciar_h.bmp", NULL);
  BITMAP* sair = load_bitmap("sprites/sair.bmp", NULL);
  BITMAP* sair_h = load_bitmap("sprites/sair_h.bmp", NULL);
  BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);
  SAMPLE* sultans = load_sample("musicas/sultans.wav");

  play_sample(sultans, 255, 128, 1000, TRUE);
  while(!exit_program && !sair_da_tela)///GAME LOOP
  {
    while(ticks > 0 && !exit_program && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ESC]) fecha_programa();

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, fundo, 0, 0);
      draw_sprite(buffer, arte, 365, 50);
      draw_sprite(buffer, iniciar, pos_botao_hor1, pos_botao_ver1);
      draw_sprite(buffer, sair, pos_botao_hor1, pos_botao_ver1 + 200);

      if(mouse_x >= pos_botao_hor1  && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 &&  mouse_y <= pos_botao_ver2)
      {
          draw_sprite(buffer, iniciar_h, pos_botao_hor1, pos_botao_ver1);
          if(mouse_b == 1)
            {
              //textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              //historia(ticks, 1);
              estado_tela = GAMESCREEN;
              stop_sample(sultans);
              game();
              play_sample(sultans, 255, 128, 1000, TRUE);
            }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 &&  mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 200 &&  mouse_y <= pos_botao_ver2 + 350)
      {
          draw_sprite(buffer, sair_h, pos_botao_hor1, pos_botao_ver1 + 200);
          if(mouse_b == 1)
          {
            stop_sample(sultans);
            fecha_programa();
          }
          //mouse_b = 0;
      }

      draw_sprite(buffer, cursor, mouse_x-8, mouse_y);
      draw_sprite(screen, buffer, 0, 0);
      clear_to_color(buffer, makecol(255, 255, 255));

      ///ATUALIZAR TICKS
      ticks--;
    }
  }
  stop_sample(sultans);
  /// DESTRUIR BITMAPS
  destroy_sample(sultans);
  destroy_bitmap(fundo);
  destroy_bitmap(arte);
  destroy_bitmap(buffer);
  destroy_bitmap(sair);
  destroy_bitmap(sair_h);
  destroy_bitmap(iniciar);
  destroy_bitmap(iniciar_h);
  destroy_bitmap(cursor);
}
END_OF_FUNCTION(menu);
