#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>
#include "personagem.h"

int bounding_box_collision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
{
    if( (x1 > x2 + w2) || (y1 > y2 + h2) || (x2 > x1 + w1) || (y2 > y1 + h1) ) //w-> LARGURA h -> ALTURA COLISAO FALSA - VERIFICACAO DOS OBJETOS QUE NAO ESTAO EM COLISAO
    return FALSE;
    else
     return TRUE;
}
