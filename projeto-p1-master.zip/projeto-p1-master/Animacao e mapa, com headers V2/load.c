#include <stdio.h>
#include <allegro.h>
#include "load.h"

void load(BITMAP* link[][7])
{

      link[0][0] = load_bitmap("link/linkr0.bmp",NULL);
      link[0][1] = load_bitmap("link/linkr1.bmp",NULL);
      link[0][2] = load_bitmap("link/linkr2.bmp",NULL);
      link[0][3] = load_bitmap("link/linkr3.bmp",NULL);
      link[0][4] = load_bitmap("link/linkr4.bmp",NULL);
      link[0][5] = load_bitmap("link/linkr5.bmp",NULL);
      link[0][6] = load_bitmap("link/linkr6.bmp",NULL);

      link[1][0] = load_bitmap("link/linkc0.bmp",NULL);
      link[1][1] = load_bitmap("link/linkc1.bmp",NULL);
      link[1][2] = load_bitmap("link/linkc2.bmp",NULL);
      link[1][3] = load_bitmap("link/linkc3.bmp",NULL);
      link[1][4] = load_bitmap("link/linkc4.bmp",NULL);
      link[1][5] = load_bitmap("link/linkc5.bmp",NULL);
      link[1][6] = load_bitmap("link/linkc6.bmp",NULL);

      link[2][0] = load_bitmap("link/linkb0.bmp",NULL);
      link[2][1] = load_bitmap("link/linkb1.bmp",NULL);
      link[2][2] = load_bitmap("link/linkb2.bmp",NULL);
      link[2][3] = load_bitmap("link/linkb3.bmp",NULL);
      link[2][4] = load_bitmap("link/linkb4.bmp",NULL);
      link[2][5] = load_bitmap("link/linkb5.bmp",NULL);
      link[2][6] = load_bitmap("link/linkb6.bmp",NULL);

      link[3][0] = load_bitmap("link/linkl0.bmp",NULL);
      link[3][1] = load_bitmap("link/linkl1.bmp",NULL);
      link[3][2] = load_bitmap("link/linkl2.bmp",NULL);
      link[3][3] = load_bitmap("link/linkl3.bmp",NULL);
      link[3][4] = load_bitmap("link/linkl4.bmp",NULL);
      link[3][5] = load_bitmap("link/linkl5.bmp",NULL);
      link[3][6] = load_bitmap("link/linkl6.bmp",NULL);
}
END_OF_FUNCTION(load);

void destroy(BITMAP* link[][7])
{
  destroy_bitmap(link[0][0]);
  destroy_bitmap(link[0][1]);
  destroy_bitmap(link[0][2]);
  destroy_bitmap(link[0][3]);
  destroy_bitmap(link[0][4]);
  destroy_bitmap(link[0][5]);
  destroy_bitmap(link[0][6]);

  destroy_bitmap(link[1][0]);
  destroy_bitmap(link[1][1]);
  destroy_bitmap(link[1][2]);
  destroy_bitmap(link[1][3]);
  destroy_bitmap(link[1][4]);
  destroy_bitmap(link[1][5]);
  destroy_bitmap(link[1][6]);

  destroy_bitmap(link[2][0]);
  destroy_bitmap(link[2][1]);
  destroy_bitmap(link[2][2]);
  destroy_bitmap(link[2][3]);
  destroy_bitmap(link[2][4]);
  destroy_bitmap(link[2][5]);
  destroy_bitmap(link[2][6]);

  destroy_bitmap(link[3][0]);
  destroy_bitmap(link[3][1]);
  destroy_bitmap(link[3][2]);
  destroy_bitmap(link[3][3]);
  destroy_bitmap(link[3][4]);
  destroy_bitmap(link[3][5]);
  destroy_bitmap(link[3][6]);
}
END_OF_FUNCTION(destroy);
