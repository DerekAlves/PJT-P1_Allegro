#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>

int bounding_box_collision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2);

