#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;



enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void historia(int nticks, int img)
{
    int t = 0;
    int sec = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    while(t < 1820)//30s
    {
        if(key[KEY_ENTER]) break;
        LOCK_VARIABLE(nticks);
        t = ticks - nticks;
        if((t % 60) == 0) sec = t/60;
        textprintf_centre_ex(buffer, font, SCREEN_W/2 + 100, SCREEN_H/2, makecol(255,255,255), -1, "%ds", sec);
        textout_centre_ex(buffer, font, "DESCRICAO AQUI", SCREEN_W/2, SCREEN_H/2, makecol(255,255,255), -1);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
    }
    destroy_bitmap(buffer);
}
END_OF_FUNCTION(historia);

void menu()
{
  int sair_da_tela = FALSE;
  int pos_botao_hor1 = 590;
  int pos_botao_hor2 = 683;
  int pos_botao_ver1 = 300;
  int pos_botao_ver2 = 336;


  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* arte = load_bitmap("sprites/artejogo.bmp", NULL);
  BITMAP* fundo = load_bitmap("sprites/fundo.bmp", NULL);
  BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
  BITMAP* highlight = load_bitmap("sprites/highlight.bmp", NULL);
  BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);
  SAMPLE* sultans = load_sample("musicas/sultans.wav");

    play_sample(sultans, 255, 128, 1000, TRUE);
  while(!exit_program && !sair_da_tela)///GAME LOOP
  {
    while(ticks > 0 && !exit_program && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ESC]) fecha_programa();

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, fundo, 0, 0);
      draw_sprite(buffer, arte, 365, 50);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 100);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 200);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 300);

      if(mouse_x >= pos_botao_hor1  && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 &&  mouse_y <= pos_botao_ver2)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1);
          if(mouse_b == 1)
            {
              textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              historia(ticks, 1);
              estado_tela = GAMESCREEN;
              stop_sample(sultans);
              game();
            }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 100 &&  mouse_y <= pos_botao_ver2 + 100)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 100);
          if(mouse_b == 1)
          {
              textout_ex(buffer, font, "CARREGAR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              stop_sample(sultans);
          }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 200 &&  mouse_y <= pos_botao_ver2 + 200)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 200);
          if(mouse_b == 1)
          {
            textout_ex(buffer, font, "CREDITOS PRESSIONADO", 590, 100, makecol(0,0,0), -1);
            stop_sample(sultans);
          }

          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 &&  mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 300 &&  mouse_y <= pos_botao_ver2 + 300)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 300);
          if(mouse_b == 1)
          {
            fecha_programa();
            stop_sample(sultans);
          }
          //mouse_b = 0;
      }

      draw_sprite(buffer, cursor, mouse_x-8, mouse_y);
      draw_sprite(screen, buffer, 0, 0);
      clear_to_color(buffer, makecol(255, 255, 255));

      ///ATUALIZAR TICKS
      ticks--;
    }
  }
  stop_sample(sultans);
  /// DESTRUIR BITMAPS
  destroy_sample(sultans);
  destroy_bitmap(fundo);
  destroy_bitmap(arte);
  destroy_bitmap(buffer);
  destroy_bitmap(button);
  destroy_bitmap(highlight);
  destroy_bitmap(cursor);
}
END_OF_FUNCTION(menu);


void game()
{
    int estmus = 0;
  int sair_da_tela = FALSE;
  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* mesa_prof = load_bitmap("sprites/objetos/professor.bmp", NULL);
  BITMAP* cadeira = load_bitmap("sprites/objetos/cadeira.bmp", NULL);
  int linhas, colunas;
  int** mapa = carregar_mapa("mapas/mapa.txt", &linhas, &colunas);
  int** ic = carregar_mapa("mapas/ic.txt", &linhas, &colunas);
  int** biblioteca = carregar_mapa("mapas/bib.txt", &linhas, &colunas);
  BITMAP* link[4][7];
  load(link);

  ///SONS
  SAMPLE* paint = load_sample("musicas/paint.wav");
  SAMPLE* takeonme = load_sample("musicas/takeonme.wav");
  SAMPLE* another = load_sample("musicas/another.wav");
  SAMPLE* silence = load_sample("musicas/silence.wav");


  ///Vari�veis
  int mapas = 0;
  int num_frames = 6;
  int frame_atual = 0; // anima��o de cada estado (andar)
  int frame_vatual = 0; // � o estado de anima��o para esquerda, direita, cima ou baixo. 0 -> direita, 1-> cima, 2-> baixo, 3-> esquerda
  int tempo_troca = 150;
//  int framew = link_dir -> w/num_frames; //pegando a largura de cada frame (da foto �nica de anima��o);
  float pos_x = 200, pos_y = 300;
  float speed = 1.5;

  ///VARIAVEIS POSICAO BIB E IC PARA COLISAO
    int pos_xi_ic = 250;
    int pos_xf_ic = 300;
    int pos_yi_ic = 350;
    int pos_yf_ic = 450;
    /// ///////////////// FIM IC /// INICIO BIB
    int pos_xi_bi = 806;
    int pos_xf_bi = 845;
    int pos_yi_bi = 404;
    int pos_yf_bi = 494;
  //GAME LOOP
  while(!exit_program)
  {
      while (ticks > 0 && !exit_program)
      {
          //INPUT
          if (key[KEY_ESC])
          {
              fecha_programa();
          }
          //UPDATE

          if (key[KEY_RIGHT])
          {
              //atualizamos o frame apenas em cada comando
              frame_vatual = 0;
              pos_x = pos_x + speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms


          }
          else if (key[KEY_DOWN])
          {
              frame_vatual = 2;
              pos_y = pos_y + speed;
               frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          }
          else if (key[KEY_UP])
          {
              frame_vatual = 1;
              pos_y = pos_y - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          else if (key[KEY_LEFT])
          {
              frame_vatual = 3;
              pos_x = pos_x - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          //frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          if (frame_vatual == 0 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 0;
          }
          if (frame_vatual == 1 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 1;
          }
          if (frame_vatual == 2 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 2;
          }
          if (frame_vatual == 3 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 3;
          }


          if (key[KEY_R])
          {
              pos_x = 200;
              pos_y = 300;
          }
          //X 250-300
          //Y 350-450

          if(mapas == 0)
          {
              desenhar_mapa(buffer, mapa, linhas, colunas);
              if(estmus == 1) stop_sample(takeonme);
              else if (estmus == 2) stop_sample(another);
              if(estmus != 3)
              {
                  play_sample(paint, 255, 128, 1000, TRUE);
                  estmus = 3;
              }
          }
          if (pos_x > pos_xi_ic && pos_x < pos_xf_ic && pos_y > pos_yi_ic && pos_y < pos_yf_ic)
          {
              if(mapas == 0)
              {
                textout_ex(buffer, font, "ENTROU NO IC", 250, 450, makecol(0,0,0), -1);
                if(key[KEY_ENTER]) mapas = 1;
              }
          }
          if (pos_x > pos_xi_bi && pos_x < pos_xf_bi && pos_y > pos_yi_bi && pos_y < pos_yf_bi)
          {
              if(mapas == 0)
              {
                textout_ex(buffer, font, "ENTROU NA BIBLIOTECA", 806, 494, makecol(0,0,0), -1);
                if(key[KEY_ENTER]) mapas = 2;
              }

          }
          if(mapas == 1)
          {
              desenhar_mapa(buffer, ic, linhas, colunas);
              draw_sprite(buffer, mesa_prof, 1180, 294);
              draw_sprite(buffer, cadeira, 1053, 294);
              draw_sprite(buffer, cadeira, 1053, 386);
              draw_sprite(buffer, cadeira, 926, 294);
              draw_sprite(buffer, cadeira, 926, 386);

              stop_sample(paint);
              if(estmus != 1)
              {
                    play_sample(takeonme, 255, 128, 1000, TRUE);
                    estmus = 1;
              }

          }
          if(mapas == 2)
          {
                desenhar_mapa(buffer, biblioteca, linhas, colunas);
                stop_sample(paint);
                if(estmus != 2)
                {
                    play_sample(another, 255, 128, 1000, TRUE);
                    estmus = 2;
                }
          }


          if(mapas == 0 && key[KEY_HOME])
          {
              stop_sample(paint);
              break;
          }
          if(key[KEY_BACKSPACE]) mapas = 0;

            draw_sprite(buffer, link[frame_vatual][frame_atual], pos_x, pos_y);
            draw_sprite(screen,buffer, 0,0);
            clear(buffer);
            ticks--;
      }
      menu();
  }

  ///FINALIZA��O
  destroy_sample(paint);
  destroy_sample(takeonme);
  destroy_sample(another);
  destroy_sample(silence);
  libera_mapa(mapa, linhas);
  libera_mapa(ic, linhas);
  libera_mapa(biblioteca, linhas);
  destroy_bitmap(mesa_prof);
  destroy_bitmap(cadeira);
  destroy_bitmap(buffer);
  destroy(link);


}
END_OF_FUNCTION(game);
