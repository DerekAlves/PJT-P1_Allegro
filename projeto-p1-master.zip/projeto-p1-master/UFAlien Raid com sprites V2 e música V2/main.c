#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum
{
    GRAMA = 1,
    BLOCO = 2,
    NBLOCO = 3,//SUBSTITUIR OS TILES POR IMAGENS
    CHAO = 4,
    BRANCO = 5,
    AZUL = 6,
};

int main()
{
    init();
    //historia(ticks, 1);

    while(!exit_program)
    {
      if(estado_tela == MAINMENU) menu();
      else if(estado_tela == GAMESCREEN) game();
    }

  return 0;
}
END_OF_MAIN()
