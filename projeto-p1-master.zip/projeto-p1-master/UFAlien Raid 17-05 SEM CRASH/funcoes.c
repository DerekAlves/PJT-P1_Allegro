#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "personagem.h"
#include "fases.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

float pos_x = 200;///
float pos_y = 300;///POSICAO PERSONAGEM

float pos[2];

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void historia(int nticks, int img)
{
    int t = 0;
    int sec = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    while(t < 1820)//30s
    {
        if(key[KEY_ENTER]) break;
        LOCK_VARIABLE(nticks);
        t = ticks - nticks;
        if((t % 60) == 0) sec = t/60;
        textprintf_centre_ex(buffer, font, SCREEN_W/2 + 100, SCREEN_H/2, makecol(255,255,255), -1, "%ds", sec);
        textout_centre_ex(buffer, font, "DESCRICAO AQUI", SCREEN_W/2, SCREEN_H/2, makecol(255,255,255), -1);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
    }
    destroy_bitmap(buffer);
}
END_OF_FUNCTION(historia);

void game()
{
  int sair_da_tela = FALSE;
  pos[0] = pos_x;
  pos[1] = pos_y;

  ufal(pos);
}
END_OF_FUNCTION(game);

void menu()
{
  int sair_da_tela = FALSE;
  int pos_botao_hor1 = 590;
  int pos_botao_hor2 = 683;
  int pos_botao_ver1 = 300;
  int pos_botao_ver2 = 336;


  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* arte = load_bitmap("sprites/artejogo.bmp", NULL);
  BITMAP* fundo = load_bitmap("sprites/fundo.bmp", NULL);
  BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
  BITMAP* highlight = load_bitmap("sprites/highlight.bmp", NULL);
  BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);
  SAMPLE* sultans = load_sample("musicas/sultans.wav");

  play_sample(sultans, 255, 128, 1000, TRUE);
  while(!exit_program && !sair_da_tela)///GAME LOOP
  {
    while(ticks > 0 && !exit_program && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ESC]) fecha_programa();

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, fundo, 0, 0);
      draw_sprite(buffer, arte, 365, 50);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 100);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 200);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 300);

      if(mouse_x >= pos_botao_hor1  && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 &&  mouse_y <= pos_botao_ver2)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1);
          if(mouse_b == 1)
            {
              textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              historia(ticks, 1);
              estado_tela = GAMESCREEN;
              stop_sample(sultans);
              game();
            }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 100 &&  mouse_y <= pos_botao_ver2 + 100)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 100);
          if(mouse_b == 1)
          {
              textout_ex(buffer, font, "CARREGAR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              stop_sample(sultans);
          }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 200 &&  mouse_y <= pos_botao_ver2 + 200)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 200);
          if(mouse_b == 1)
          {
            textout_ex(buffer, font, "CREDITOS PRESSIONADO", 590, 100, makecol(0,0,0), -1);
            stop_sample(sultans);
          }

          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 &&  mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 300 &&  mouse_y <= pos_botao_ver2 + 300)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 300);
          if(mouse_b == 1)
          {
            stop_sample(sultans);
            fecha_programa();
          }
          //mouse_b = 0;
      }

      draw_sprite(buffer, cursor, mouse_x-8, mouse_y);
      draw_sprite(screen, buffer, 0, 0);
      clear_to_color(buffer, makecol(255, 255, 255));

      ///ATUALIZAR TICKS
      ticks--;
    }
  }
  stop_sample(sultans);
  /// DESTRUIR BITMAPS
  destroy_sample(sultans);
  destroy_bitmap(fundo);
  destroy_bitmap(arte);
  destroy_bitmap(buffer);
  destroy_bitmap(button);
  destroy_bitmap(highlight);
  destroy_bitmap(cursor);
}
END_OF_FUNCTION(menu);
