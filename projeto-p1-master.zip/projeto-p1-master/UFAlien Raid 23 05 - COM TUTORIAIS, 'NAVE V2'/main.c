#include <allegro.h>
#include <stdio.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "fases.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum{ MAINMENU, GAMESCREEN };
int estado_tela;

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

int main()
{
    init();

    while(!exit_program)
    {
      if(estado_tela == MAINMENU) menu();
      else if(estado_tela == GAMESCREEN) game();
    }

  return 0;
}
END_OF_MAIN()
