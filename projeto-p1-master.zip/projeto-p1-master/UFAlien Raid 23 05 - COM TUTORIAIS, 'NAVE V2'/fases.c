#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"
#include "fases.h"
#include "personagem.h"
#define num_balas 10

int ticks = 0;

BITMAP* boneco[4][3];
int ticks;
int flag_tiro = 1;

int posobjx()
{
    //srand(time(NULL));
    int r = rand() %800;

    return r;
}
int posobjy ()
{
    //srand(time(NULL));
    int r = rand() % 500;
    return r;

}


struct projeteis // global
{

	int x;
	int y;
	int velocidade;
	int ativo; // ativar ou desativar a municao -> 0 para desativado e 1 para desativado


}balas[num_balas];

     //VARIAVEIS GLOBAIS
    float pos_nx = 0;
    float pos_ny = 0;
    float speed_x = 10;
    float speed_y = 5;
    float speedx = 2;
    float speedy = 2;
    int flag_tiro;

enum
{
    ATIVO,
    NAO_ATIVO
};


void iniciar_tiros(BITMAP* bullet) // carregar os tiros num arra
{
    int i;
    for (i=0; i<num_balas; i++)
    {
        balas[i].ativo = NAO_ATIVO;
        balas[i].velocidade = 7;
    }
    flag_tiro = 0;

}
void show_tiros(BITMAP* bullet, BITMAP* buffer, float pos[2]) //movimentacao dos projeteis
{

    int i;
    for (i=0; i<num_balas; i++)
    {
        if (balas[i].ativo == ATIVO)
        {
            draw_sprite(buffer, bullet, balas[i].x, balas[i].y);
            if (balas[i].x > buffer->w || balas[i].x>1018 && balas[i].y>190 && balas[i].y<352 || balas[i].x>717 && balas[i].y>120 && balas[i].y < 170
                ||balas[i].x>717 && balas[i].y>260 && balas[i].y<310 ||balas[i].x>717 && balas[i].y>435 && balas[i].y<485
                ||balas[i].x > 417 && balas[i].y > 120 && balas[i].y<170||  balas[i].x > 417 && balas[i].y > 260 && balas[i].y < 310 ||  balas[i].x > 417 && balas[i].y > 435 && balas[i].y<485)
            {
                balas[i].ativo = NAO_ATIVO;
            }
            else
            {
                 balas[i].x+=balas[i].velocidade;
            }
        }
    }
}

void atirar() // acionar os tiros com uma tecla
{
    int i;
    for (i=0; i<num_balas; i++)
    {
        if (balas[i].ativo == NAO_ATIVO)
        {
            balas[i].ativo = ATIVO;
            balas[i].x = pos_nx + 130;
            balas[i].y = pos_ny + 48;

            break;
        }
    }
}

int bounding_box_collision(float posc[2], float w1, float h1, int x2, int y2, int w2, int h2)
{
    if( (posc[0] > x2 + w2) || (posc[1] > y2 + h2) || (x2 > posc[0] + w1) || (y2 > posc[1] + h1) ) return FALSE;
    else return TRUE;
}

int atingiu (float posc[2], float w1, float h1)
{

    for (int i = 0; i<num_balas; i++)
    {
          if(bounding_box_collision(posc, 30, 34, balas[i].x, balas[i].y, 32, 8) == TRUE)
         {
                float life_draw = 20;

                balas[i].x-=(balas[i].velocidade*(-50));
                balas[i].ativo = NAO_ATIVO;

                printf ("pegou\n");
                return life_draw;

                break;

         }
    }
    //if (bounding_box_collision(posc,30,34,)
}

void colisao (float posc[2], float w, float h, int x1, int y1, int w1, int h1,float speedx, float speedy)
{

    if(bounding_box_collision(posc, 30, 34, x1, y1, w1 , h1) == TRUE)
         {
              if (posc[0] > x1)
             {
                 posc[0]+=speedx;



             }
             if (posc[1] > y1)
             {
                 posc[1]+=speedy;


             }
             if (posc[0] < x1)
             {
                 posc[0]-=speedx;

             }
             if (posc[1] < y1)
             {
                 posc[1]-=speedy;


             }
         }
}


void icomp(float pos[2])
{
	int score = 100;
	int score_j = 0;
	int linhas, colunas;
	int xd, yd;
	int atingido = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	BITMAP* mesa_prof = load_bitmap("sprites/objetos/professor.bmp", NULL);
  	BITMAP* cadeira = load_bitmap("sprites/objetos/cadeira.bmp", NULL);
  	SAMPLE* takeonme = load_sample("musicas/takeonme.wav");
    BITMAP* bullet = load_bitmap("bullet.bmp", NULL);
    BITMAP* nave = load_bitmap("nave.bmp", NULL);
    BITMAP* disk = load_bitmap ("sprites/objetos/disquete.bmp",NULL);
    SAMPLE* sfx = load_sample("sfx.wav");
  	int** ic = carregar_mapa("mapas/ic.txt", &linhas, &colunas);
  	play_sample(takeonme, 255, 128, 1000, TRUE);
  	iniciar_tiros(bullet);
  	int diskativo = 0;
  	float life = 100;
  	pos[0] = 1100;
  	pos[1] = 225;


  	while(score_j < score && !key[KEY_BACKSPACE] && life > 0)
	{


		if (pos_ny < 0)
        {
             speed_y *= -1;
        }
        else if (pos_ny>605)
        {
            speed_y *= -1;
        }

        pos_ny += speed_y;

        if(flag_tiro == 1)
        {
            //play_sample(sfx, 50, 128, 1000, FALSE);///PARA A MUSICA
            atirar();
        }
        flag_tiro++;
        if(flag_tiro == 24) flag_tiro = 1;

        desenhar_mapa(buffer, ic, linhas, colunas);
        rectfill(buffer, 1170, 15, 1250, 35, makecol(0,0,0));
		textprintf_ex(buffer, font, 1175, 20, makecol(0,255,0), -1, "SCORE: %d", score_j);
		draw_sprite(buffer, mesa_prof, 1050, 200);
		draw_sprite(buffer, cadeira, 747, 120);
		draw_sprite(buffer, cadeira, 747, 260);
		draw_sprite(buffer, cadeira, 747, 435);
		draw_sprite(buffer, cadeira, 447, 120);
		draw_sprite(buffer, cadeira, 447, 260);
		draw_sprite(buffer, cadeira, 447, 435);
		colisao(pos, 30,34,1050,200,mesa_prof->w, mesa_prof->h,speedx,speedy);
		colisao(pos,30,34,747,120,cadeira->w,cadeira->h,speedx,speedy);
		colisao(pos,30,34,747,260,cadeira->w,cadeira->h,speedx,speedy);
		colisao(pos,30,34,747,435,cadeira->w,cadeira->h,speedx,speedy);
        colisao(pos,30,34,447,120,cadeira->w,cadeira->h,speedx,speedy);
        colisao(pos,30,34,447,260,cadeira->w,cadeira->h,speedx,speedy);
        colisao(pos,30,34,447,435,cadeira->w,cadeira->h,speedx,speedy);
        colisao(pos,30,34,pos_nx,pos_ny,nave->w,nave->h,speedx,speedy);

		if (diskativo == 0)
        {
            diskativo = 1;
            xd = posobjx();
            yd = posobjy();
            printf("x %d y %d\n", xd, yd);
            //speed_y+=5;
        }
        if (pos[0]+30 >= xd && pos[0]-30 <= xd && pos[1]+34 >= yd && pos[1]-34<=yd)
        {
            diskativo = 0;
            score_j += 10;
        }
        if (diskativo == 1)
        {
             draw_sprite(buffer, disk, xd , yd);
             printf("DESENHOU\n");
        }
        life -=  atingiu(pos, 30, 34);

        rectfill(buffer, 15, 15, 95, 35, makecol(0,0,0));
        textprintf_ex(buffer, font, 20, 20, makecol(255,0,0), -1, "LIFE: %.0f", life);
		draw_sprite_ex(buffer, nave, pos_nx, pos_ny, DRAW_SPRITE_NORMAL, DRAW_SPRITE_NO_FLIP);
		show_tiros(bullet, buffer, pos);
		personagem(buffer, boneco, pos);

		draw_sprite(screen, buffer, 0, 0);
		clear(buffer);

	}
	if(life <= 0) historia(ticks, 3, 181);///3s
	else historia(ticks, 4, 600);///10s
	libera_mapa(ic, linhas);
	stop_sample(takeonme);
	destroy_sample(takeonme);
	destroy_bitmap(buffer);
	destroy_bitmap(mesa_prof);
	destroy_bitmap(cadeira);
	destroy_bitmap(nave);
    destroy_sample(sfx);
    destroy_bitmap(disk);
    destroy_bitmap(bullet);
}
END_OF_FUNCTION(icomp);

void bibli(float pos[2])
{
	int score = 1000;
	int linhas, colunas;
	BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	int** biblioteca = carregar_mapa("mapas/bib.txt", &linhas, &colunas);
	SAMPLE* another = load_sample("musicas/another.wav");

	play_sample(another, 255, 128, 1000, TRUE);

	while(score > 0 && !key[KEY_BACKSPACE])
	{
		desenhar_mapa(buffer, biblioteca, linhas, colunas);
		personagem(buffer, boneco, pos);
		draw_sprite(screen, buffer, 0, 0);
		clear(buffer);
    }
	libera_mapa(biblioteca, linhas);
	destroy_bitmap(buffer);
	stop_sample(another);
	destroy_sample(another);

}
END_OF_FUNCTION(bibli);

void ufal(float pos[2])
{
    int estmus = 0;


	int linhas, colunas;
	BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
	int** mapa = carregar_mapa("mapas/mapa.txt", &linhas, &colunas);
	SAMPLE* paint = load_sample("musicas/paint.wav");
	load(boneco);

	///VARIAVEIS POSICAO BIB E IC PARA COLISAO
    int pos_xi_ic = 250;
    int pos_xf_ic = 300;
    int pos_yi_ic = 350;
    int pos_yf_ic = 450;
    /// ///////////////// FIM IC /// INICIO BIB
    int pos_xi_bi = 806;
    int pos_xf_bi = 845;
    int pos_yi_bi = 404;
    int pos_yf_bi = 494;
    pos[0] = 315;
    pos[1] = 215;

    play_sample(paint, 255, 128, 1000, TRUE);

	while(!key[KEY_HOME])
	{
		if(pos[0] > pos_xi_ic && pos[0] < pos_xf_ic && pos[1] > pos_yi_ic && pos[1] < pos_yf_ic)
		{


			textout_ex(buffer, font, "ENTROU NO IC", 250, 450, makecol(0,0,0), -1);
            if(key[KEY_ENTER])
            {

                estmus = 1;
                historia(ticks, 2, 1821);///30s
            	stop_sample(paint);
            	icomp(pos);
            	play_sample(paint, 255, 128, 1000, TRUE);
            }

		}
		else if (pos[0] > pos_xi_bi && pos[0] < pos_xf_bi && pos[1] > pos_yi_bi && pos[1] < pos_yf_bi)
        {
            textout_ex(buffer, font, "ENTROU NA BIBLIOTECA", 806, 494, makecol(0,0,0), -1);
            if(key[KEY_ENTER])
            {
                estmus = 1;
                stop_sample(paint);
            	bibli(pos);
            	play_sample(paint, 255, 128, 1000, TRUE);
            }
        }

        //if(estmus == 1) play_sample(paint, 255, 128, 1000, TRUE);

        desenhar_mapa(buffer, mapa, linhas, colunas);
        personagem(buffer, boneco, pos);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
        ticks--;
	}
	libera_mapa(mapa, linhas);
	stop_sample(paint);
	destroy_sample(paint);
	destroy_bitmap(buffer);
	destroy(boneco);

}
END_OF_FUNCTION(ufal);
