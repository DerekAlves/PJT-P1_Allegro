#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;



enum{ MAINMENU, GAMESCREEN };
int estado_tela;

void historia(int nticks, int img)
{
    int t = 0;
    int sec = 0;
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    while(t < 1820)
    {
        LOCK_VARIABLE(nticks);
        t = ticks - nticks;
        if((t % 60) == 0) sec = t/60;
        textprintf_centre_ex(buffer, font, SCREEN_W/2 + 100, SCREEN_H/2, makecol(255,255,255), -1, "%ds", sec);
        textout_centre_ex(buffer, font, "DESCRICAO AQUI", SCREEN_W/2, SCREEN_H/2, makecol(255,255,255), -1);
        draw_sprite(screen, buffer, 0, 0);
        clear(buffer);
    }
    destroy_bitmap(buffer);
}
END_OF_FUNCTION(historia);

void game()
{
  int sair_da_tela = FALSE;
  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  int linhas, colunas;
  int** mapa = carregar_mapa("mapas/mapa.txt", &linhas, &colunas);
  BITMAP* link[4][7];
  load(link);

  ///Vari�veis
  int num_frames = 6;
  int frame_atual = 0; // anima��o de cada estado (andar)
  int frame_vatual = 0; // � o estado de anima��o para esquerda, direita, cima ou baixo. 0 -> direita, 1-> cima, 2-> baixo, 3-> esquerda
  int tempo_troca = 150;
//  int framew = link_dir -> w/num_frames; //pegando a largura de cada frame (da foto �nica de anima��o);
  float pos_x = 200, pos_y = 300;
  float speed = 1.5;
  //GAME LOOP
  while(!exit_program)
  {
      while (ticks > 0 && !exit_program)
      {
          //INPUT
          if (key[KEY_ESC])
          {
              fecha_programa();
          }
          //UPDATE

          if (key[KEY_RIGHT])
          {
              //atualizamos o frame apenas em cada comando
              frame_vatual = 0;
              pos_x = pos_x + speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms


          }
          else if (key[KEY_DOWN])
          {
              frame_vatual = 2;
              pos_y = pos_y + speed;
               frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          }
          else if (key[KEY_UP])
          {
              frame_vatual = 1;
              pos_y = pos_y - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          else if (key[KEY_LEFT])
          {
              frame_vatual = 3;
              pos_x = pos_x - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          //frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          if (frame_vatual == 0 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 0;
          }
          if (frame_vatual == 1 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 1;
          }
          if (frame_vatual == 2 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 2;
          }
          if (frame_vatual == 3 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 3;
          }


          if (key[KEY_R])
          {
              pos_x = 200;
              pos_y = 300;
          }

            desenhar_mapa(buffer, mapa, linhas, colunas);
            draw_sprite(buffer, link[frame_vatual][frame_atual], pos_x,pos_y);
            draw_sprite(screen,buffer, 0,0);
            clear_to_color(buffer, makecol(255,255,255));
            ticks--;
      }
  }

  ///FINALIZA��O
  libera_mapa(mapa, linhas);
  destroy_bitmap(buffer);
  destroy(link);


}
END_OF_FUNCTION(game);

void menu()
{
  int sair_da_tela = FALSE;
  int pos_botao_hor1 = 590;
  int pos_botao_hor2 = 683;
  int pos_botao_ver1 = 200;
  int pos_botao_ver2 = 236;


  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
  BITMAP* highlight = load_bitmap("sprites/highlight.bmp", NULL);
  BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);


  while(!exit_program && !sair_da_tela)///GAME LOOP
  {
    while(ticks > 0 && !exit_program && !sair_da_tela)
    {
      ///ENTRADA
      if(key[KEY_ESC]) fecha_programa();

      ///ATUALIZACAO

      ///DESENHAR
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 100);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 200);
      draw_sprite(buffer, button, pos_botao_hor1, pos_botao_ver1 + 300);

      if(mouse_x >= pos_botao_hor1  && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 &&  mouse_y <= pos_botao_ver2)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1);
          if(mouse_b == 1)
            {
              textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
              historia(ticks, 1);
              estado_tela = GAMESCREEN;
              game();
            }
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 100 &&  mouse_y <= pos_botao_ver2 + 100)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 100);
          if(mouse_b == 1) textout_ex(buffer, font, "CARREGAR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 && mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 200 &&  mouse_y <= pos_botao_ver2 + 200)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 200);
          if(mouse_b == 1) textout_ex(buffer, font, "CREDITOS PRESSIONADO", 590, 100, makecol(0,0,0), -1);
          //mouse_b = 0;
      }
      else if(mouse_x >= pos_botao_hor1 &&  mouse_x <= pos_botao_hor2 && mouse_y >= pos_botao_ver1 + 300 &&  mouse_y <= pos_botao_ver2 + 300)
      {
          draw_sprite(buffer, highlight, pos_botao_hor1, pos_botao_ver1 + 300);
          if(mouse_b == 1) fecha_programa();
          //mouse_b = 0;
      }

      draw_sprite(buffer, cursor, mouse_x-8, mouse_y);
      draw_sprite(screen, buffer, 0, 0);
      clear_to_color(buffer, makecol(255, 255, 255));

      ///ATUALIZAR TICKS
      ticks--;
    }
  }
  /// DESTRUIR BITMAPS
  destroy_bitmap(buffer);
  destroy_bitmap(button);
  destroy_bitmap(highlight);
  destroy_bitmap(cursor);
}
END_OF_FUNCTION(menu);
