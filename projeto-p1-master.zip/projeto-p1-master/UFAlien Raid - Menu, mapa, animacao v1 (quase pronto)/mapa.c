#include <allegro.h>
#include <stdio.h>
#include "funcoes.h"
#include "inicio.h"
#include "load.h"
#include "mapa.h"

const int TILESIZE = 50;

enum
{
    GRAMA = 1,
    BLOCO = 2,
    NBLOCO = 3,//SUBSTITUIR OS TILES POR IMAGENS
    CHAO = 4
};

int** carregar_mapa(const char* arquivo, int* linhas, int* colunas)
{
    FILE* f = fopen(arquivo, "r");
    int** matriz;

    if(f != NULL)
    {
        int i, j;
        fscanf(f, "%d %d", linhas, colunas);

        matriz = (int**) malloc ( (*linhas) * sizeof(int*));
        for(i=0; i < *linhas; i++)
            matriz[i] = (int*) malloc( (*colunas) * sizeof(int));

        for(i = 0; i < *linhas; i++)
        {
            for(j = 0; j < *colunas; j++)
            {
            fscanf(f, "%d", &matriz[i][j]);//queria saber o que é um fscanf
            }
     }

     fclose(f);
    }
    return matriz;
}

void desenhar_mapa(BITMAP* buffer, int** mapa, int linhas, int colunas)//esse eu uso os coiso da outra pra pintar os quadrados, quando formos incrementar o mapa é só mexer nessa aqui eu acho
{
    int i, j;

    for(i = 0; i < linhas; i++)
     {
        for(j = 0; j < colunas; j++)
        {
           if(mapa[i][j] == GRAMA)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(0,230,0));

           else if(mapa[i][j] == BLOCO)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(70,160,255));

           else if(mapa[i][j] == NBLOCO)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(215,0,0));

           else if(mapa[i][j] == CHAO)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(133,133,133));
        }
     }
}

void libera_mapa(int** mapa, int linhas)
{
   int i;
   for(i = 0; i < linhas; i++) free(mapa[i]);

  	free(mapa);
}
