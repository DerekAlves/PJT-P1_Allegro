#include <stdio.h>
#include <allegro.h>
#include <stdlib.h>
#include "inicio.h"
#include "mapa.h"

volatile int exit_program;
volatile int ticks;
volatile int milisegundos;

enum
{
    GRAMA = 1,
    BLOCO = 2,
    NBLOCO = 3,
    CHAO = 4
};

int main()
{
  init();

  ///BITMAPS
  BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
  int linhas, colunas;
  int** mapa = carregar_mapa("mapas/mapa.txt", &linhas, &colunas);

  BITMAP* link[4][7];
  /*link_esq[0] = load_bitmap("link_esq01.bmp", NULL);
  link_esq[1] = load_bitmap("link_esq02.bmp", NULL);
  link_esq[2] = load_bitmap("link_esq03.bmp", NULL);
  link_esq[3] = load_bitmap("link_esq04.bmp", NULL);*/
  link[0][0] = load_bitmap("link/linkr0.bmp",NULL);
  link[0][1] = load_bitmap("link/linkr1.bmp",NULL);
  link[0][2] = load_bitmap("link/linkr2.bmp",NULL);
  link[0][3] = load_bitmap("link/linkr3.bmp",NULL);
  link[0][4] = load_bitmap("link/linkr4.bmp",NULL);
  link[0][5] = load_bitmap("link/linkr5.bmp",NULL);
  link[0][6] = load_bitmap("link/linkr6.bmp",NULL);

  link[1][0] = load_bitmap("link/linkc0.bmp",NULL);
  link[1][1] = load_bitmap("link/linkc1.bmp",NULL);
  link[1][2] = load_bitmap("link/linkc2.bmp",NULL);
  link[1][3] = load_bitmap("link/linkc3.bmp",NULL);
  link[1][4] = load_bitmap("link/linkc4.bmp",NULL);
  link[1][5] = load_bitmap("link/linkc5.bmp",NULL);
  link[1][6] = load_bitmap("link/linkc6.bmp",NULL);

  link[2][0] = load_bitmap("link/linkb0.bmp",NULL);
  link[2][1] = load_bitmap("link/linkb1.bmp",NULL);
  link[2][2] = load_bitmap("link/linkb2.bmp",NULL);
  link[2][3] = load_bitmap("link/linkb3.bmp",NULL);
  link[2][4] = load_bitmap("link/linkb4.bmp",NULL);
  link[2][5] = load_bitmap("link/linkb5.bmp",NULL);
  link[2][6] = load_bitmap("link/linkb6.bmp",NULL);

  link[3][0] = load_bitmap("link/linkl0.bmp",NULL);
  link[3][1] = load_bitmap("link/linkl1.bmp",NULL);
  link[3][2] = load_bitmap("link/linkl2.bmp",NULL);
  link[3][3] = load_bitmap("link/linkl3.bmp",NULL);
  link[3][4] = load_bitmap("link/linkl4.bmp",NULL);
  link[3][5] = load_bitmap("link/linkl5.bmp",NULL);
  link[3][6] = load_bitmap("link/linkl6.bmp",NULL);
  //BITMAP* link_dir = load_bitmap("link_dir.bmp", NULL);


  ///Vari�veis
  int num_frames = 6;
  int frame_atual = 0; // anima��o de cada estado (andar)
  int frame_vatual = 0; // � o estado de anima��o para esquerda, direita, cima ou baixo. 0 -> direita, 1-> cima, 2-> baixo, 3-> esquerda
  int tempo_troca = 150;
//  int frame_w = link_dir -> w/num_frames; //pegando a largura de cada frame (da foto �nica de anima��o);
  float pos_x = 200, pos_y = 300;
  float speed = 0.7;
  //GAME LOOP
  while(!exit_program)
  {
      while (ticks > 0 && !exit_program)
      {
          //INPUT
          if (key[KEY_ESC])
          {
              fecha_programa();
          }
          //UPDATE

          if (key[KEY_RIGHT])
          {
              //atualizamos o frame apenas em cada comando
              frame_vatual = 0;
              pos_x = pos_x + speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms


          }
          else if (key[KEY_DOWN])
          {
              frame_vatual = 2;
              pos_y = pos_y + speed;
               frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          }
          else if (key[KEY_UP])
          {
              frame_vatual = 1;
              pos_y = pos_y - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          else if (key[KEY_LEFT])
          {
              frame_vatual = 3;
              pos_x = pos_x - speed;
              frame_atual = (milisegundos/tempo_troca) % num_frames;
          }
          //frame_atual = (milisegundos/tempo_troca) % num_frames; //ent�o cada frame ter� 1 ms
          if (frame_vatual == 0 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 0;
          }
          if (frame_vatual == 1 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 1;
          }
          if (frame_vatual == 2 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 2;
          }
          if (frame_vatual == 3 && !key[KEY_RIGHT] && !key[KEY_LEFT] && !key[KEY_DOWN] && !key[KEY_UP])
          {
              frame_atual = 0;
              frame_vatual = 3;
          }


          if (key[KEY_R])
          {
              pos_x = 200;
              pos_y = 300;
          }
            //DRAW
           // masked_blit(link_dir, buffer, frame_atual*frame_w, 0,400,300,frame_w, link_dir -> h); // esse aqui desenha uma imagem �nica em partes cortadas. quando o frame for 0, a fonte ser� 0, quando for 1, a fonte ser� no final da primeira largura

            //draw_sprite(buffer, link_esq[frame_atual],pos_x,pos_y);
            desenhar_mapa(buffer, mapa, linhas, colunas);
            draw_sprite(buffer, link[frame_vatual][frame_atual], pos_x,pos_y);
            draw_sprite(screen,buffer, 0,0);
            clear_to_color(buffer, makecol(255,255,255));
            ticks--;
      }
  }

  ///FINALIZA��O
  libera_mapa(mapa, linhas);
  destroy_bitmap(buffer);
/*  destroy_bitmap(link_dir);
  destroy_bitmap(link_esq[0]);
  destroy_bitmap(link_esq[1]);
  destroy_bitmap(link_esq[2]);
  destroy_bitmap(link_esq[3]);*/

  destroy_bitmap(link[0][0]);
  destroy_bitmap(link[0][1]);
  destroy_bitmap(link[0][2]);
  destroy_bitmap(link[0][3]);
  destroy_bitmap(link[0][4]);
  destroy_bitmap(link[0][5]);
  destroy_bitmap(link[0][6]);

  destroy_bitmap(link[1][0]);
  destroy_bitmap(link[1][1]);
  destroy_bitmap(link[1][2]);
  destroy_bitmap(link[1][3]);
  destroy_bitmap(link[1][4]);
  destroy_bitmap(link[1][5]);
  destroy_bitmap(link[1][6]);

  destroy_bitmap(link[2][0]);
  destroy_bitmap(link[2][1]);
  destroy_bitmap(link[2][2]);
  destroy_bitmap(link[2][3]);
  destroy_bitmap(link[2][4]);
  destroy_bitmap(link[2][5]);
  destroy_bitmap(link[2][6]);

  destroy_bitmap(link[3][0]);
  destroy_bitmap(link[3][1]);
  destroy_bitmap(link[3][2]);
  destroy_bitmap(link[3][3]);
  destroy_bitmap(link[3][4]);
  destroy_bitmap(link[3][5]);
  destroy_bitmap(link[3][6]);



  return 0;
}
END_OF_MAIN();

