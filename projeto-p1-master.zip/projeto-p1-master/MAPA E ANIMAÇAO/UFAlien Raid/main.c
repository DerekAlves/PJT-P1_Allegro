#include <allegro.h>

/*void menu()
{
    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
    BITMAP* highlight = load_bitmap("highlight/button.bmp", NULL);
    draw_sprite(buffer, button, 200, 200);
    draw_sprite(buffer, button, 200, 300);
    draw_sprite(buffer, button, 200, 400);
    draw_sprite(buffer, button, 200, 500);
    draw_sprite(screen, buffer, 0, 0);

}*/


int main()
{
   allegro_init();
   install_timer();
   install_mouse();
   install_keyboard();
   set_color_depth(32);
   set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 1280, 720, 0, 0);
   set_window_title("Tutorial 1 - Instalacao");

   BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
   BITMAP* button = load_bitmap("sprites/button.bmp", NULL);
   BITMAP* highlight = load_bitmap("sprites/highlight.bmp", NULL);
   BITMAP* cursor = load_bitmap("sprites/cursor.bmp", NULL);


   while(!key[KEY_ESC])///GAME LOOP
   {
    draw_sprite(buffer, button, 590, 200);
    draw_sprite(buffer, button, 590, 300);
    draw_sprite(buffer, button, 590, 400);
    draw_sprite(buffer, button, 590, 500);

    if(mouse_x >=590 && mouse_x <= 683 && mouse_y >= 200 &&  mouse_y < 236)
    {
        draw_sprite(buffer, highlight, 590, 200);
        if(mouse_b == 1) textout_ex(buffer, font, "NOVO JOGO PRESSIONADO", 590, 100, makecol(0,0,0), -1);
        //mouse_b = 0;
    }
    else if(mouse_x >=590 && mouse_x <= 683 && mouse_y >= 300 &&  mouse_y < 336)
    {
        draw_sprite(buffer, highlight, 590, 300);
        if(mouse_b == 1) textout_ex(buffer, font, "CARREGAR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
        //mouse_b = 0;
    }
    else if(mouse_x >=590 && mouse_x <= 683 && mouse_y >= 400 &&  mouse_y < 436)
    {
        draw_sprite(buffer, highlight, 590, 400);
        if(mouse_b == 1) textout_ex(buffer, font, "CREDITOS PRESSIONADO", 590, 100, makecol(0,0,0), -1);
        //mouse_b = 0;
    }
    else if(mouse_x >=590 &&  mouse_x <= 683 && mouse_y >= 500 &&  mouse_y < 536)
    {
        draw_sprite(buffer, highlight, 590, 500);
        if(mouse_b == 1) textout_ex(buffer, font, "SAIR PRESSIONADO", 590, 100, makecol(0,0,0), -1);
        //mouse_b = 0;
    }

    draw_sprite(buffer, cursor, mouse_x-9, mouse_y);
    draw_sprite(screen, buffer, 0, 0);
    clear_to_color(buffer, makecol(255, 255, 255));
   }

   destroy_bitmap(buffer);
   destroy_bitmap(button);
   destroy_bitmap(highlight);

   return 0;
}
END_OF_MAIN()
