#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>

const int TILESIZE = 50;

enum //n sei o que isso faz
{
    SOLO = 0,
    GRAMA = 1,
    AGUA = 2,
    LAVA = 3,
    PEDRA = 4
};

int** carregar_mapa(const char* arquivo, int* linhas, int* colunas) //essa carrega o mapa, monte de coisa de ponteiro que n sei mas ok
{
    FILE* f = fopen(arquivo, "r");
    int** matriz;

    if(f != NULL)
    {
        int i, j;
        fscanf(f, "%d %d", linhas, colunas);

        matriz = (int**) malloc ( (*linhas) * sizeof(int*));
        for(i=0; i < *linhas; i++)
            matriz[i] = (int*) malloc( (*colunas) * sizeof(int));

        for(i = 0; i < *linhas; i++)
        {
            for(j = 0; j < *colunas; j++)
            {
            fscanf(f, "%d", &matriz[i][j]);//queria saber o que � um fscanf
            }
     }

     fclose(f);
    }
    return matriz;
}


void Desenhar_Mapa(BITMAP* buffer, int** mapa, int linhas, int colunas)//esse eu uso os coiso da outra pra pintar os quadrados, quando formos incrementar o mapa � s� mexer nessa aqui eu acho
{
    int i, j;

    for(i = 0; i < linhas; i++)
     {
        for(j = 0; j < colunas; j++)
        {
           if(mapa[i][j] == SOLO)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(183,150,89));

           else if(mapa[i][j] == GRAMA)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(0,230,0));

           else if(mapa[i][j] == AGUA)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(70,160,255));

           else if(mapa[i][j] == LAVA)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(215,0,0));

           else if(mapa[i][j] == PEDRA)
             rectfill(buffer, j * TILESIZE, i * TILESIZE, (j * TILESIZE) + TILESIZE, (i * TILESIZE) + TILESIZE, makecol(133,133,133));
        }
     }
}

void Libera_Mapa(int** mapa, int linhas)//preciso realmente ver o video pela terceira vez
{
   int i;
   for(i = 0; i < linhas; i++)
    free(mapa[i]);

   free(mapa);
}

volatile int ticks;
void tick_counter() { ticks++; }
END_OF_FUNCTION(tick_counter)

int main()
{
    allegro_init();
    install_timer();
    install_keyboard();
    install_mouse();
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 1280, 720, 0, 0);

    ticks = 0;
    LOCK_FUNCTION(tick_counter);
    LOCK_VARIABLE(ticks);
    install_int_ex(tick_counter, BPS_TO_TIMER(60));

    BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);
    int sair = 0;
    int linhas, colunas;
    int** mapa = carregar_mapa("mapa.txt", &linhas, &colunas);

    while(sair!=1)
    {
        if(key[KEY_ESC]) sair = 1;
        while(ticks>0)
        {

            Desenhar_Mapa(buffer, mapa, linhas, colunas);
            draw_sprite(screen, buffer, 0, 0);
            clear_to_color(buffer, makecol(255,255,255));

            ticks--;
        }

    }
        Libera_Mapa(mapa, linhas);
        destroy_bitmap(buffer);

    return 0;
}
END_OF_MAIN();
